# This program assigns a grade based on the user's score

# Step 1: Ask the user to enter their score
score = int(input("Enter your score (0 to 100): "))

# Step 2: Use conditional statements to determine the grade
if score >= 80 and score <= 100:
    grade = "A"
elif score >= 70 and score <= 79:
    grade = "B"
elif score >= 60 and score <= 69:
    grade = "C"
elif score >= 50 and score <= 59:
    grade = "D"
elif score < 50 and score >= 0:
    grade = "F"
else:
    grade = "Invalid score"  # For scores outside 0–100

# Step 3: Print the result
print("Your grade is:", grade)