# This program processes a list of 5 numbers

# Step 1: Let user enter 5 numbers and store them in a list
numbers = []

print("Enter 5 numbers:")
for i in range(5):
    num = int(input())
    numbers.append(num)

# Step 2: Display the list
print("Numbers:", numbers)

# Step 3: Show max, min, and average
print("Maximum:", max(numbers))
print("Minimum:", min(numbers))
average = sum(numbers) / len(numbers)
print("Average:", average)

# Step 4: Sort and display the list
sorted_list = sorted(numbers)
print("Sorted:", sorted_list)