# Ask user for length and width
length = float(input("Enter length: "))
width = float(input("Enter width: "))

# Calculate area and perimeter
area = length * width
perimeter = 2 * (length + width)

# Display the results
print("Area:", area)
print("Perimeter:", perimeter)

