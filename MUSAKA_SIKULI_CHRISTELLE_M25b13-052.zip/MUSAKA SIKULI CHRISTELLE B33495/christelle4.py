# This function checks if a number is prime
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

# Ask the user for a number
number = int(input("Enter a number: "))

# Check and display whether it is prime
if is_prime(number):
    print(number, "is a prime number.")
else:
    print(number, "is not a prime number.")